# Arduino-Eagle-Cad-Library
Eagle Cad Library for Arduino Mini and Nano
This is an Eagle Cad Library that contains Arduino nano and Arduino pro Mini pin outs.

It gives you a single part that can be placed on a schematic/board so you can simply solder in or plug in 
an Arduino pro mini or nano into your project.

v1.3 Corrected several cosmetic issues and Added a pinout for the StepStick Stepper Controler.
